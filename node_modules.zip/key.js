console.log('this is loaded');
exports.Password = {
    password: process.env.password,
    
};